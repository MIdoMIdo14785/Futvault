FUTVault static site

Edit data/games.json to add or update games. Upload files to GitHub repo and enable Pages (main / root).